def handler(event, context):
    return {'status': 'PathTriage 07 lab — env vars are the issue'}
